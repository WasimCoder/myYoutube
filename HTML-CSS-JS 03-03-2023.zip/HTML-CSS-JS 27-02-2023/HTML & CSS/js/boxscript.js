let iconButton = document.querySelector('.app-block');
document.querySelector('#burger-icon').onclick = () =>{
    iconButton.classList.toggle('active');
}
let searchButton = document.querySelector(".search-block");
document.querySelector('.ytapps-icon').onclick = () =>{
    searchButton.classList.toggle('');
    notifButton.classList.remove('active');
    iconButton.classList.remove('active');
}
