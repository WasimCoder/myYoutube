let vid = document.getElementById("vid-pre");
let vtime = document.getElementById("vt");
let video = document.getElementsByClassName("vid");
let videoThumb = document.getElementById("thumb");
let videoPlay = document.getElementById("video");
let div = document.getElementById("work");
let iframe = document.getElementById("iframe-div");

let iconButton = document.querySelector('.app-block');
document.querySelector('.ytapps-icon').onclick = () =>{
    iconButton.classList.toggle('apps-active');
    notifButton.classList.remove('notif-active');
    searchButton.classList.remove('search-active');
}
let notifButton = document.querySelector(".notif-block");
document.querySelector('.bell-icon').onclick = () =>{
    notifButton.classList.toggle('notif-active');
    iconButton.classList.remove('apps-active');  
    searchButton.classList.remove('search-active');
}
let searchButton = document.querySelector(".search-block");
document.querySelector('.search-bar').onclick = () =>{
    searchButton.classList.toggle('search-active');
    iconButton.classList.remove('apps-active');
    notifButton.classList.remove('notif-active');
   
}

// let vidTime = document.getElementsById("v-time")
// videoPlay.classList.remove("video");
// function myFunction(){
//     videoThumb.inner="";
//     videoPlay.classList.toggle("video");
// }
// videoThumb.addEventListener('mouseenter',(e)=>{
//     setTimeout(()=>{
//         videoThumb.style.display = "none"
//         videoPlay.style.display = "inline"
//     },2000)
    
// })
// video.addEventListener('mouseenter',(e)=>{
//     setTimeout(()=>{
//         videoThumb.style.display = "none"
//         videoPlay.style.display = "inline"
        
//     },2000)
    
// })
// video.addEventListener('mouseout',(e)=>{
//     setTimeout(()=>{
//         videoThumb.style.display = "inline"
//         videoPlay.style.display = "none"
        
//     },500)
    
// })
vid.addEventListener('mouseenter',(e)=>{
    setTimeout(()=>{
        iframe.style.paddingBottom = "56.25%"
        videoThumb.style.display = "none"
        videoPlay.style.display = "inline"
        videoPlay.style.paddingBottom = "56.25%"
        vtime.style.display ="none"
        
    },2000)
    
})
vid.addEventListener('mouseleave',(e)=>{
    setTimeout(()=>{
        iframe.style.paddingBottom = "0"
        videoThumb.style.display = "inline"
        videoPlay.style.display = "none"
        vtime.style.display ="block"
    
},1000)})
