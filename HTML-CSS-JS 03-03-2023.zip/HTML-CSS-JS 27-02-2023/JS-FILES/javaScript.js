var heading = document.firstElementChild.lastElementChild.firstElementChild;
heading.innerHTML="how are you";
heading.style.color = "red";
document.querySelector(".b1").style.color = "red";
document.querySelector(".b1").style.backgroundColor = "white";
document.querySelector("input").click();
document.getElementsByTagName('li');//Gets element by tag name
document.getElementsByTagName('li')[2].style.color="grey";//The index of tag can be selected like an array and the value can be modified
document.getElementById("title").innerHTML="I'm fine"; //Gets element by ID and change inner content
document.querySelectorAll("#list .list a")[0].style.color = "green";
document.querySelector('button').classList //lists the class associated with the tag/element 
document.querySelector('button').classList.add("invisible");//Adds a class to the tag
document.querySelector('button').classList.toggle("invisible");//Toggles the tag to work or not work
document.querySelector('h1').classList.add("huge");
document.querySelector("a").attributes;//lists the attributes of the tag
document.querySelector("a").getAttribute("href");//Obtain the value of the attribute
document.querySelector("a").setAttribute("href","www.outlook.com");//Change the value of that attribute
element.addEventListener(type,function (){});//Used for adding an event and response to that event
function add(num1,num2){ return num1+num2; };
function sub(num1,num2){ return num1-num2; };
function mul(num1,num2){ return num1*num2; };
function div(num1,num2){ return num1/num2; };
function mod(num1,num2){ return num1%num2; };
function pow(num1,num2){ return Math.pow(num1,num2); };
function calc(num1,num2,operator){ return operator(num1,num2)};
calc(4,5,add);//Higher order functions (functions taking another function as parameter)
calc(4,5,sub);
calc(4,5,mul);
calc(4,5,div);
calc(4,5,mod);
calc(4,5,pow);
//An event is a task which is done by the user. Eg: click, scroll etc.

// <!--firstElementChild = the First element to ever start the program. In this case, HTML-->
// <!--firstElementChild.firstElementChild = The first element of the first elementc child. In this case, Head-->
// <!--firstElementChild.lastElementChild = The last element of the first elementc child. In this case Body-->
// <!--
// var heading = document.firstElementChild.lastElementChild.firstElementChild;//Accessing h1
// heading.innerHTML="how are you"; //changing text of h1;
// heading.style.color = "red"; //Giving background color to button;
// document.querySelector("input").click(); //Clicks or ticks the checkbox button
/*
RHS value always "Under double quotes"
innerHTML = Obtains the Total HTML inside the element. Can change the whole HTML inside
text content =  Obtains only the test inside the element. Can change only the text
 */
