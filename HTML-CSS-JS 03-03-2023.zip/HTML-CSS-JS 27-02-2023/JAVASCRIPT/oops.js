//Why objects must be created?
//To maintain one set of variables and call all of them
//whenever they are needed

let person = {
    name: "Wasim",
    age: 24,
    interest: ['programming'],
    isAlive: true,
    address: {
        city: "Chennai",
        state: "TamilNadu",
        nation: "India"
    },
    greeting: function () {
        let msg = "Hello " + this.name + " You are " + this.age + " years old from " + this.address.city;
        let msg2 = `My name is ${this.name}` //This is tilda method
        console.log(msg);//<this> keyword is used for referring the variable present inside an object
        console.log(msg2);
    }
}
console.log(person.greeting()) //returns undefined at last because the fubnction didn't return anything