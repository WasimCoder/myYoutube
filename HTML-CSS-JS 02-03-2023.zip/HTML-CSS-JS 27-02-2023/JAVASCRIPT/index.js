//Alerting
//let, var are variable syntax like int string etc but let is usually preferred
//Just like python, don't need to specify datatype
//Syntax = let <variable-name> = value; 
// let name = "Wasim";
// var message = "Hello to you too" + name + "Nice to meet you";
// // alert("Hello to you too");
// console.log(message);
// //Logging
// console.log("Hello Everyone");
/*
variable rules : 
1. No javaScript keyword names
2. Should not start with number
3. Should not have space or hyphen
4. Prefer camelCase
5. variable names are case sensitive
6. Keep meaningful names
*/
let num1 = 10;
let num2 = 20;
console.log(num1 + num2);

/*
For Big applications : let
For very simple applications : var

*/
const name = "wasim";
console.log(name);
//const variable is used for permanently assigning a value
