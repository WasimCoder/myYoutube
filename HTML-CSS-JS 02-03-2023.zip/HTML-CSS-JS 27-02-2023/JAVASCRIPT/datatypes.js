/* Datatypes in javaScript
There are two types of datatypes in javaScript:
1. Primitive data Type
    Eg:
    String
    integer/ Number
    Boolean
    undefined
    null
2. Reference Type 
    Eg:
    1. Object
    2. Array
    3. Functions*/
//Eg - 1:
let fname = "Wasim"; //String

let age = 22; //Integer

let isYoung = true //Boolean

//{
let lname; /* or*/
let lname2 = undefined;
//} undefined

let trophy = null;//null. Since it doesn't have anything, it will store as an object

/*There are 2 types of datatype languages
1. Statically Typed eg: String name = "Wasim";
2. Dynamically Typed eg: name = "Wasim;"
javaScript is a Dynamically typed language
*/

//Eg - 2:
//Object

/*Data in Objects are stored in a specific format i.e.;
key : the name of the variable/attribute/property
value : the value of that key
syntax : let <variable-name> : {
    key1 : value1 , key2 : value2 , key3 : value3
}*/
let person = {
    name: "Akthar",
    age: 22,
    gender: "male",
    address: "chennai",
}//Object


//You can print the key and values by mentioning the object name

console.log(person);

/*To call a specific key present in the object, the calling syntax is:
console.log(ObjName.keyname)
This is called Dot Notation 
Eg:- */

console.log(person.name);

/*The key cannot be changed but the value inside key can be changed
Eg:- */

person.age = 24;
console.log(person.age);

/*You can call the value of a key by mentioning the key name in quotes inside box brackets
This is called bracket Notation. Dot notation is usually preferred 
Eg:- */

console.log(person['gender']);

/* You can create object within an object. The object created inside is called as Sub Object
Eg:- */

let mobile = {
    brands: {
        Android: "oppo",
        iOS: "Apple"
    },
    price: {
        flagship: 30000,
        normal: 10000
    }
}
console.log(mobile); //output: the object with Sub Objects

/*You can easily call the Sub Object by ,mentioning the key of the Sub Object after mentioning the key of the Object*/

console.log(mobile.price.flagship); //output: 30000


//Arrays
/*Arrays are initialised by gving square brackets []
Eg:- */

let myFavColors = ["Black", "Blue"]; //This is an empty array
console.log(myFavColors); //output : []
/*You can call only a specific value in an array by calling it's index value */
console.log(myFavColors[1]);//output: Blue
/*You can create an index anywhere in the array
Eg:- */
myFavColors[4] = "green";
console.log(myFavColors);
/*Output :
(5) ['Black', 'Blue', empty × 2, 'green']
0: "Black"
1: "Blue"
4: "green"
length: 5 */
/*You can add any datatype in arrays
Eg:- */
let channel = ["Name", 1234, true, 98.76];
console.log(channel); //Output : (4) ['Name', 1234, true, 98.76]
/*You can check the length by using dot notation and the word 'length'
Eg:- */
console.log(channel.length);

//Function
/*Function is initialized by using the keyword function
Syntax : function <variable-name>([formal args, parameters or none]){ 
 //Statements
}
Eg:- */
function greetUser() {
    let myName = "Wasim Akthar";
    let message = "hello, my name is " + myName;
    console.log(message);
}

/*A function is called by it's name along with () 
Eg:- */
greetUser(); //Output : hello, my name is Wasim Akthar

/*You can give a function a parameter which can be given as
an input by the user and the function can use the input 
inside the statements
Eg:- */
function details(user_name, age) {
    console.log("Your name is " + user_name + " and your age is " + age);
}
details("Wasim", 22);//Output : Your name is Wasim and your age is 22

/*If a parameter is present in a function and the value 
is not passed while it's called, it'll print undefined 
Eg:- */
details("Wasim"); //Output : Your name is Wasim and your age is undefined






