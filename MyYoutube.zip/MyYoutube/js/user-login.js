// var pp = document.querySelector('.profile-icon');
var box = document.querySelector('.box');

document.querySelector('#profile-icon').onclick = () =>{
  box.classList.toggle('box-active');
}
document.querySelector('.sign-out').onclick = () =>{
  location.replace('youtube-login.html')
}