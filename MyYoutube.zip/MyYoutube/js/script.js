

let iconButton = document.querySelector('.app-block');
document.querySelector('.ytapps-icon').onclick = () =>{
    iconButton.classList.toggle('apps-active');
    notifButton.classList.remove('notif-active');
    searchButton.classList.remove('search-active');
}
let notifButton = document.querySelector(".notif-block");
document.querySelector('.bell-icon').onclick = () =>{
    notifButton.classList.toggle('notif-active');
    iconButton.classList.remove('apps-active');  
    searchButton.classList.remove('search-active');
}
let searchButton = document.querySelector(".search-block");
document.querySelector('.search-bar').onclick = () =>{
    searchButton.classList.toggle('search-active');
    iconButton.classList.remove('apps-active');
    notifButton.classList.remove('notif-active');
   
}

// let vidTime = document.getElementsById("v-time")
// videoPlay.classList.remove("video");
// function myFunction(){
//     videoThumb.inner="";
//     videoPlay.classList.toggle("video");
// }
// videoThumb.addEventListener('mouseenter',(e)=>{
//     setTimeout(()=>{
//         videoThumb.style.display = "none"
//         videoPlay.style.display = "inline"
//     },2000)
    
// })
// video.addEventListener('mouseenter',(e)=>{
//     setTimeout(()=>{
//         videoThumb.style.display = "none"
//         videoPlay.style.display = "inline"
        
//     },2000)
    
// })
// video.addEventListener('mouseout',(e)=>{
//     setTimeout(()=>{
//         videoThumb.style.display = "inline"
//         videoPlay.style.display = "none"
        
//     },500)
    
// })

// let vid = document.getElementById("vid-pre");
// let vtime = document.getElementById("vt");
// let video = document.getElementsByClassName("vid");
// let videoThumb = document.getElementById("thumb");
// let videoPlay = document.getElementById("video");
// let div = document.getElementById("work");
// let iframe = document.getElementById("iframe-div");

//PLAN-1


// let vid = document.getElementById("vid-pre");
// let vtime = document.getElementById("vt");
// let video = document.getElementsByClassName("vid");
// let videoThumb = document.getElementById("thumb");
// let videoPlay = document.getElementById("video");
// let div = document.getElementById("work");
// let iframe = document.getElementById("iframe-div");

// vid.addEventListener('mouseenter',(e)=>{
//     setTimeout(()=>{
//         iframe.style.paddingBottom = "56.25%"
//         videoThumb.style.display = "none"
//         videoPlay.style.display = "inline"
//         videoPlay.style.paddingBottom = "56.25%"
//         vtime.style.display ="none"
        
//     },2000)
    
// })
// vid.addEventListener('mouseleave',(e)=>{
//     setTimeout(()=>{
//         iframe.style.paddingBottom = "0"
//         videoThumb.style.display = "inline"
//         videoPlay.style.display = "none"
//         vtime.style.display ="block"
    
// },1000)})


//PLAN 2


// for (let i = 1; i <= document.querySelectorAll(".video-preview").length; i++) {
//     let vid = document.getElementById("vid-pre"+i);
//     // let div = document.getElementById("work"+i);
//     // let video = document.getElementsByClassName("vid"+i);
//     let videoThumb = document.getElementById("thumb"+i);
//     let videoPlay = document.getElementById("video"+i);
//     let vtime = document.getElementById("vt"+i);
//     let iframe = document.getElementById("iframe-div"+i);
//     vid.addEventListener('mouseenter',(e)=>{
//         setTimeout(()=>{
//             iframe.style.paddingBottom = "56.25%"
//             videoThumb.style.display = "none"
//             videoPlay.style.display = "inline"
//             videoPlay.style.paddingBottom = "56.25%"
//             vtime.style.display ="none"
            
//         },2000)
        
//     })
//     vid.addEventListener('mouseleave',(e)=>{
//         setTimeout(()=>{
//             iframe.style.paddingBottom = "0"
//             videoThumb.style.display = "inline"
//             videoPlay.style.display = "none"
//             vtime.style.display ="block"
        
//     },1000)})
    
    
// }

//PLAN-3
 for (let i = 0; i < document.querySelectorAll(".video-preview").length; i++) {
        let vid = document.querySelectorAll(".video-preview")[i];
        // let div = document.getElementById("work"+i);
        let videoThumb = document.querySelectorAll(".thumb")[i];
        let iframe = document.querySelectorAll(".iframe-div")[i];
        let videoPlay = document.querySelectorAll(".iframe-video")[i];
        let vtime = document.querySelectorAll(".vt")[i];
       setTimeout(()=>{
        vid.addEventListener('mouseenter',(e)=>{
            setTimeout(()=>{
                videoPlay.setAttribute("allow","autoplay")
                iframe.style.paddingBottom = "56.25%"
                videoThumb.style.display = "none"
                videoPlay.style.display = "inline"
                videoPlay.style.paddingBottom = "56.25%"
                vtime.style.display ="none"
                
            },1000)
        }) 
            
        },500)
        setTimeout(()=>{
        vid.addEventListener('mouseleave',(e)=>{
            setTimeout(()=>{
                videoPlay.setAttribute("allow"," ")
                iframe.style.paddingBottom = "0"
                videoThumb.style.display = "inline"
                videoPlay.style.display = "none"
                vtime.style.display ="block"
            
        },1000)
    })
    },500)
        
    }

const searchInput = document.querySelector('.search-bar');
const searchBtn = document.querySelector('.search-button');
let searchLink = "https://www.youtube.com/results?search_query=";

searchBtn.addEventListener('click', () => {
    if(searchInput.value.length){
        location.href = searchLink + searchInput.value;
    }
})
// side2.toggleAttribute('disabled');
// let side1 = document.getElementById('side1');
// let side2 = document.getElementById('side2');
// document.getElementById('menu-ham').addEventListener('click', ()=>{
//     console.log("hello");
// })



const
  normalStyle   = document.getElementById('side1'),
  invertedStyle = document.getElementById('side2');
    let filters = document.querySelector(".filters");

    normalStyle.style.display = "block";
    invertedStyle.style.display = "none";

    invertedStyle.setAttribute("disabled","");
    normalStyle.setAttribute("disabled","");

    normalStyle.toggleAttribute("disabled")

    document.getElementById('menu1').addEventListener('click', () => {
    normalStyle.style.display = "none";

    document.querySelector(".left-filter").classList.toggle("lfb-active");

    filters.classList.toggle("filter-active");

    normalStyle.style.transition = "1s linear";
    invertedStyle.style.transition = "1s linear";

    invertedStyle.toggleAttribute("disabled")
    normalStyle.toggleAttribute("disabled")

    invertedStyle.style.display = "block";

    // console.log('hel');
    })

    let leftFilter = document.getElementById("lfb");
    let rightFilter = document.getElementById("rfb");
    let filterBox = document.getElementById("filter");
   leftFilter.onclick = () =>{
    filterBox.scrollLeft -=100;
   }
    rightFilter.onclick = () =>{
    filterBox.scrollLeft +=100;
   }
//    leftFilter.addEventListener('click', ()=> {
//     event.preventDefault();
//     filterBox.animate()
//    })
//    rightFilter.addEventListener('click', ()=> {
//     filterBox.style.translate = "10px 0"
//    })


