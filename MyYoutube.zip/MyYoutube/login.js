let loginDetails = {
  username: ["wasim"],
  password: ["akthar"]
 }
var x = document.getElementById('login')
var y = document.getElementById('register')
var z = document.getElementById('btn')
var c1 = document.getElementById("btn1")
var c2 = document.getElementById("btn2")
c2.addEventListener("click", function(){
  c1.style.color = "black";
  c2.style.color = "white";
  c1.style.transition = "1s"
})
c1.addEventListener("click", function(){
  c2.style.color = "black";
  c1.style.color = "white";
  c2.style.transition = "1s"
})
/*var x = $('#login')
var y = $('#register')
var z = $('#btn') */
y.style.display = 'none';
function register(){
  x.style.display = "none";
  x.style.transition = "1s";
  y.style.display = "block";
  z.style.left = "100px";
  x.style.color = "black"

}
function login(){
  y.style.color = "black"
  y.style.display = "none";
  x.style.display = "block";
  y.style.transition = "1s";
  z.style.left = "0px";

}

let logUser = document.getElementById("user");
let logPass = document.getElementById("pass");
let loginButton = document.getElementById("login-button");
/*
let logUser =$("#user");
let logPass =$("#pass");
let loginButton =$("#login-button");
 */
// loginButton.addEventListener('click',function(event){
//   window.location.replace("http://127.0.0.1:5502/youtube.html?");
// })
const submitButton = document.getElementById("login-button");
const form = document.getElementById("login");

submitButton.addEventListener("click", function(event) {
  // Prevent the default form submission behavior
  event.preventDefault();

  // Your code here to handle the form submission
  // For example, you can use the FormData API to get the form data:
  const formData = new FormData(form);
  const username = formData.get("User");
  const password = formData.get("Pass");
  console.log("Username:", username);
  console.log("Password:", password);
  // After handling the form submission, you can redirect the user to a new page:
  for(var i = 0; i<loginDetails.username.length;i++){
  if(username===loginDetails.username[i] && password===loginDetails.password[i]){
    window.location.assign("youtube.html?");
  }
}
for(var i = 0; i<loginDetails.username.length;i++){
  if((username!==loginDetails.username[i] && password===loginDetails.password[i])||(username===loginDetails.username[i] && password!==loginDetails.password[i]) || (username!==loginDetails.username[i] && password!==loginDetails.password[i])){
    form.reset();
  }
}
});

const registerButton = document.getElementById("register-button");
const form2 = document.getElementById("register");

registerButton.addEventListener("click", function(event) {
  // Prevent the default form submission behavior
  event.preventDefault();

  // Your code here to handle the form submission
  // For example, you can use the FormData API to get the form data:
  const formData2 = new FormData(form2);
  const Nusername = formData2.get("Nuser");
  const Nemail = formData2.get("Nmail")
  const Npassword = formData2.get("Npass");
  const Npassword2 = formData2.get("Npass2");
  console.log("New Username:", Nusername);
  console.log("New Email:", Nemail);
  console.log("New Password:", Npassword);
  console.log("Rewritten Password:", Npassword2);
  // After handling the form submission, you can redirect the user to a new page:
  if (Npassword!==Npassword2){
    alert("Write same password");
    form2.reset();
  }
  else{
    alert("Your account has been created successfully");
    loginDetails.username.push(Nusername);
    loginDetails.password.push(Npassword);
    Nusername = ""
    Npassword, Npassword2 = "";
    console.log(Nusername);
    console.log(Npassword);
    console.log(Npassword2);
  }
});
 