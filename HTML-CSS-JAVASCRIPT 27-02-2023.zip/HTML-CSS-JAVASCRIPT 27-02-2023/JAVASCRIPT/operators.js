/*Operators :-
To solve a problem in a program, operators are neeeded
Variable + Operators = Expression(Algorithm)
JavaScrpt Operators:-
1. Arithmetic Operators
2. Comparison Operators
3. Assignment Operators
4. Bitwise Operators
5. Logical Operators
*/

//Arithmetic operators: + - * / % ** ++ --

let num1 = 20;
let num2 = 5;
console.log(num1 + num2); // Addition
console.log(num1 - num2); // subtraction
console.log(num1 * num2); // multiplication
console.log(num1 / num2); // division
console.log(num1 % num2); // remainder division
console.log(num1 ** num2);// power
console.log(num1++);//post increment
console.log(++num1);//pre increment
console.log(num1--);//post decrement
console.log(--num1);//pre decrement

//Assignment operators:   = += -= *= %= /= **=

console.log(num1 += num2); // Addition
console.log(num1 -= num2); // subtraction
console.log(num1 *= num2); // multiplication
console.log(num1 /= num2); // division
console.log(num1 %= num2); // remainder division
console.log(num1 **= num2);// power

//Comparison Operators: < > <= >= !=(not Equal to) ==(Equal To) 
//Result will be in boolean

console.log(num1 < num2);
console.log(num1 > num2);
console.log(num1 <= num2);
console.log(num1 >= num2);
console.log(num1 != num2);

//String comparison can also be done in javaScript
console.log("Wasim" > "Akthar");
console.log("1" < 5);//True because js tries to find num in string and compares

//Strict Equality Operators !==(not Equal to) ===(Equal To)
//This was introduced so that the string above won't convert to integer
//It checks whether the datatype and value are same

console.log("1" === 1);

//Ternary operators var name = <condition> ? <statement1> : <statement2>

let time = 10;
let hour = time < 20 ? true : false;
console.log(hour)

//Logical Operators &&  || !
//Falsy and Truthy are used for comparing boolean with value
/*Falsy Examples:-
undefined
null
0
false
'' -> ""
NaN
Anything that's not this is truthy*/

//Conditional Operators (Like java ) :-
/*if 
if-else
else-if
switch
*/

/*ctrl + shift + i = used for alignment 
Date is an inbuilt function used for getting the date and time
Syntax = let <var-name> = new Date();*/

const person ={
    jill: 1,
    jang: 2,
    juck: 3
}
for (let key in person){
    console.log(key + " : " +person[key])
}
let colors = ["Red","blue","Green"];
for(let key in colors){
    console.log(colors[key]);
}

for ( let color of colors){
    console.log("Color: " + color);
}
